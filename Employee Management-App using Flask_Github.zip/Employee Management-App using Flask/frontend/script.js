const apiUrl = 'http://localhost:3000/employees';
const empTableBody = document.getElementById('empTableBody');
const empForm = document.getElementById('empForm');
const formScreen = document.getElementById('FormScreen');
const tableScreen = document.getElementById('EmployeeTableScreen');
const messageBox = document.getElementById('message');
const phoneInput = document.getElementById('phone');
const phoneError = document.getElementById('phoneError');

// Store all employees globally
let allEmployees = [];

function showForm() {
  document.getElementById('formTitle').innerText = 'New Employee Details';
  empForm.reset();
  formScreen.classList.remove('hidden');
  tableScreen.classList.add('hidden');
}

function cancelForm() {
  formScreen.classList.add('hidden');
  tableScreen.classList.remove('hidden');
}

function validatePhone() {
  const phone = phoneInput.value;
  if (!/^\d*$/.test(phone)) {
    phoneError.textContent = 'Only numbers allowed';
  } else if (phone.length > 10) {
    phoneError.textContent = 'Phone number must be 10 digits';
  } else {
    phoneError.textContent = '';
  }
}

function isValidEmail(email) {
  const regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return regex.test(email);
}

function loadEmployees() {
  fetch(apiUrl)
    .then(res => res.json())
    .then(data => {
      allEmployees = data; // update global list
      empTableBody.innerHTML = '';
      data.forEach(emp => {
        const row = document.createElement('tr');
        row.innerHTML = `
          <td>${emp.id}</td>
          <td data-field="name">${emp.name}</td>
          <td data-field="dept">${emp.dept}</td>
          <td data-field="email">${emp.email}</td>
          <td data-field="phone">${emp.phone}</td>
          <td>
            <button class="button btn-update" onclick="enableEdit(this, ${emp.id})">Update</button>
            <button class="button btn-delete" style="background-color:red;color:white;" onclick="confirmDelete(${emp.id})">Delete</button>
          </td>
        `;
        empTableBody.appendChild(row);
      });
    });
}

empForm.addEventListener('submit', function (e) {
  e.preventDefault();
  const name = document.getElementById('name').value.trim();
  const dept = document.getElementById('dept').value.trim();
  const email = document.getElementById('email').value.trim();
  const phone = document.getElementById('phone').value.trim();

  if (!isValidEmail(email)) {
    alert('Invalid email format');
    return;
  }

  if (!/^\d{10}$/.test(phone)) {
    alert('Phone number must be 10 digits');
    return;
  }

  // Check for duplicates in allEmployees
  const isDuplicate = allEmployees.some(emp =>
    (emp.name === name && emp.dept === dept) ||
    emp.email === email ||
    emp.phone === phone
  );

  if (isDuplicate) {
    alert("Duplicate entry detected");
    return;
  }

  fetch(apiUrl, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ name, dept, email, phone })
  })
    .then(res => res.json())
    .then(() => {
      showMessage('Employee created successfully');
      cancelForm();
      loadEmployees();
    });
});

function enableEdit(button, id) {
  const row = button.closest('tr');
  const cells = row.querySelectorAll('[data-field]');

  cells.forEach(cell => {
    const field = cell.dataset.field;
    const input = document.createElement('input');
    input.value = cell.textContent;
    input.setAttribute('data-field', field);
    cell.innerHTML = '';
    cell.appendChild(input);
  });

  button.textContent = 'Save';
  button.onclick = () => saveUpdate(row, id);

  // Hide delete button
  const deleteBtn = button.parentElement.querySelector('.btn-delete');
  if (deleteBtn) deleteBtn.remove(); // completely remove delete button
  
  // Add cancel button
  let cancelBtn = button.parentElement.querySelector('.btn-cancel');
  if (!cancelBtn) {
    cancelBtn = document.createElement('button');
    cancelBtn.className = 'button btn-cancel';
    cancelBtn.textContent = 'Cancel';
    cancelBtn.onclick = () => loadEmployees();
    button.parentElement.appendChild(cancelBtn);
  }
}

function saveUpdate(row, id) {
  const name = row.querySelector('input[data-field="name"]').value.trim();
  const dept = row.querySelector('input[data-field="dept"]').value.trim();
  const email = row.querySelector('input[data-field="email"]').value.trim();
  const phone = row.querySelector('input[data-field="phone"]').value.trim();

  if (!isValidEmail(email)) {
    alert('Invalid email format');
    return;
  }

  if (!/^\d{10}$/.test(phone)) {
    alert('Phone must be 10 digits and contain only numbers');
    return;
  }

  // Check for duplicate on update (excluding current record)
  const isDuplicate = allEmployees.some(emp =>
    emp.id !== id &&
    (
      (emp.name === name && emp.dept === dept) ||
      emp.email === email ||
      emp.phone === phone
    )
  );

  if (isDuplicate) {
    alert("Duplicate entry detected while updating");
    return;
  }

  fetch(`${apiUrl}/${id}`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ name, dept, email, phone })
  })
    .then(res => res.json())
    .then(() => {
      showMessage('Employee updated successfully');
      loadEmployees();
    });
}

function confirmDelete(id) {
  const confirmed = confirm('Are you sure you want to delete this employee?');
  if (!confirmed) return;

  fetch(`${apiUrl}/${id}`, { method: 'DELETE' })
    .then(res => res.json())
    .then(() => {
      showMessage('Employee deleted');
      loadEmployees();
    });
}

function showMessage(msg) {
  messageBox.textContent = msg;
  messageBox.classList.remove('hidden');
  setTimeout(() => messageBox.classList.add('hidden'), 2000);
}

loadEmployees();




