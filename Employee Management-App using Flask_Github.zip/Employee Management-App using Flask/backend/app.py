from flask import Flask, request, jsonify
from db import get_connection
from flask_cors import CORS
app = Flask(__name__)
CORS(app)

@app.route('/employees', methods=['GET'])
def get_employees():
    conn = get_connection()
    cursor = conn.cursor(dictionary=True)
    cursor.execute("SELECT * FROM employees")
    result = cursor.fetchall()
    cursor.close()
    conn.close()
    return jsonify(result)

@app.route('/employees/<int:emp_id>', methods=['GET'])
def get_employee(emp_id):
    conn = get_connection()
    cursor = conn.cursor(dictionary=True)
    cursor.execute("SELECT * FROM employees WHERE id = %s", (emp_id,))
    result = cursor.fetchone()
    cursor.close()
    conn.close()
    return jsonify(result)

@app.route('/employees', methods=['POST'])
def add_employee():
    data = request.json
    name, dept, email, phone = data['name'], data['dept'], data['email'], data['phone']

    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("""SELECT * FROM employees 
                      WHERE email=%s OR phone=%s OR (name=%s AND dept=%s)""",
                   (email, phone, name, dept))
    if cursor.fetchone():
        return jsonify({'message': 'Duplicate employee found.'}), 400

    cursor.execute("INSERT INTO employees (name, dept, email, phone) VALUES (%s, %s, %s, %s)",
                   (name, dept, email, phone))
    conn.commit()
    cursor.close()
    conn.close()
    return jsonify({'message': 'Employee added!'})

@app.route('/employees/<int:emp_id>', methods=['PUT'])
def update_employee(emp_id):
    data = request.json
    name, dept, email, phone = data['name'], data['dept'], data['email'], data['phone']

    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("""UPDATE employees 
                      SET name=%s, dept=%s, email=%s, phone=%s 
                      WHERE id=%s""",
                   (name, dept, email, phone, emp_id))
    conn.commit()
    cursor.close()
    conn.close()
    return jsonify({'message': 'Employee updated!'})

@app.route('/employees/<int:emp_id>', methods=['DELETE'])
def delete_employee(emp_id):
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("DELETE FROM employees WHERE id=%s", (emp_id,))
    conn.commit()
    cursor.close()
    conn.close()
    return jsonify({'message': 'Employee deleted!'})

if __name__ == '__main__':
    app.run(debug=True, port=3000)
